﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalAutomation
{
    class Ilac
    {
        public int ID { get; set; }
        public int MedicineId { get; set; }
        public string MedicineName { get; set; }

    }
}
