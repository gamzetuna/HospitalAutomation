﻿
namespace HospitalAutomation
{
    partial class HastaKayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_tcno = new System.Windows.Forms.Label();
            this.lbl_ad = new System.Windows.Forms.Label();
            this.lbl_soyad = new System.Windows.Forms.Label();
            this.lbl_dt = new System.Windows.Forms.Label();
            this.lbl_cinsiyet = new System.Windows.Forms.Label();
            this.lbl_telno = new System.Windows.Forms.Label();
            this.chx_durum = new System.Windows.Forms.CheckBox();
            this.txt_tc = new System.Windows.Forms.TextBox();
            this.txt_ad = new System.Windows.Forms.TextBox();
            this.txt_soyad = new System.Windows.Forms.TextBox();
            this.txt_telno = new System.Windows.Forms.TextBox();
            this.dtp_dt = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btn_kaydet = new System.Windows.Forms.Button();
            this.btn_düzenle = new System.Windows.Forms.Button();
            this.btn_sil = new System.Windows.Forms.Button();
            this.btn_temizle = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbl_soyadara = new System.Windows.Forms.Label();
            this.btn_hasta_ara = new System.Windows.Forms.Button();
            this.txt_hastatc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_tcno
            // 
            this.lbl_tcno.AutoSize = true;
            this.lbl_tcno.Location = new System.Drawing.Point(76, 36);
            this.lbl_tcno.Name = "lbl_tcno";
            this.lbl_tcno.Size = new System.Drawing.Size(68, 17);
            this.lbl_tcno.TabIndex = 0;
            this.lbl_tcno.Text = "T.C No :";
            // 
            // lbl_ad
            // 
            this.lbl_ad.AutoSize = true;
            this.lbl_ad.Location = new System.Drawing.Point(95, 79);
            this.lbl_ad.Name = "lbl_ad";
            this.lbl_ad.Size = new System.Drawing.Size(42, 17);
            this.lbl_ad.TabIndex = 1;
            this.lbl_ad.Text = "Ad : ";
            // 
            // lbl_soyad
            // 
            this.lbl_soyad.AutoSize = true;
            this.lbl_soyad.Location = new System.Drawing.Point(76, 119);
            this.lbl_soyad.Name = "lbl_soyad";
            this.lbl_soyad.Size = new System.Drawing.Size(68, 17);
            this.lbl_soyad.TabIndex = 2;
            this.lbl_soyad.Text = "Soyad : ";
            // 
            // lbl_dt
            // 
            this.lbl_dt.AutoSize = true;
            this.lbl_dt.Location = new System.Drawing.Point(31, 172);
            this.lbl_dt.Name = "lbl_dt";
            this.lbl_dt.Size = new System.Drawing.Size(120, 17);
            this.lbl_dt.TabIndex = 3;
            this.lbl_dt.Text = "Doğum Tarihi : ";
            // 
            // lbl_cinsiyet
            // 
            this.lbl_cinsiyet.AutoSize = true;
            this.lbl_cinsiyet.Location = new System.Drawing.Point(67, 220);
            this.lbl_cinsiyet.Name = "lbl_cinsiyet";
            this.lbl_cinsiyet.Size = new System.Drawing.Size(75, 17);
            this.lbl_cinsiyet.TabIndex = 4;
            this.lbl_cinsiyet.Text = "Cinsiyet :";
            // 
            // lbl_telno
            // 
            this.lbl_telno.AutoSize = true;
            this.lbl_telno.Location = new System.Drawing.Point(50, 263);
            this.lbl_telno.Name = "lbl_telno";
            this.lbl_telno.Size = new System.Drawing.Size(98, 17);
            this.lbl_telno.TabIndex = 5;
            this.lbl_telno.Text = "Telefon Nu :";
            // 
            // chx_durum
            // 
            this.chx_durum.AutoSize = true;
            this.chx_durum.Location = new System.Drawing.Point(64, 307);
            this.chx_durum.Name = "chx_durum";
            this.chx_durum.Size = new System.Drawing.Size(77, 21);
            this.chx_durum.TabIndex = 6;
            this.chx_durum.Text = "Durum";
            this.chx_durum.UseVisualStyleBackColor = true;
            // 
            // txt_tc
            // 
            this.txt_tc.Location = new System.Drawing.Point(161, 33);
            this.txt_tc.Name = "txt_tc";
            this.txt_tc.Size = new System.Drawing.Size(200, 22);
            this.txt_tc.TabIndex = 7;
            // 
            // txt_ad
            // 
            this.txt_ad.Location = new System.Drawing.Point(161, 76);
            this.txt_ad.Name = "txt_ad";
            this.txt_ad.Size = new System.Drawing.Size(200, 22);
            this.txt_ad.TabIndex = 8;
            // 
            // txt_soyad
            // 
            this.txt_soyad.Location = new System.Drawing.Point(161, 119);
            this.txt_soyad.Name = "txt_soyad";
            this.txt_soyad.Size = new System.Drawing.Size(200, 22);
            this.txt_soyad.TabIndex = 9;
            // 
            // txt_telno
            // 
            this.txt_telno.Location = new System.Drawing.Point(161, 263);
            this.txt_telno.Name = "txt_telno";
            this.txt_telno.Size = new System.Drawing.Size(200, 22);
            this.txt_telno.TabIndex = 10;
            // 
            // dtp_dt
            // 
            this.dtp_dt.Location = new System.Drawing.Point(161, 172);
            this.dtp_dt.Name = "dtp_dt";
            this.dtp_dt.Size = new System.Drawing.Size(200, 22);
            this.dtp_dt.TabIndex = 13;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.txt_tc);
            this.groupBox1.Controls.Add(this.dtp_dt);
            this.groupBox1.Controls.Add(this.lbl_tcno);
            this.groupBox1.Controls.Add(this.lbl_ad);
            this.groupBox1.Controls.Add(this.lbl_soyad);
            this.groupBox1.Controls.Add(this.txt_telno);
            this.groupBox1.Controls.Add(this.lbl_dt);
            this.groupBox1.Controls.Add(this.txt_soyad);
            this.groupBox1.Controls.Add(this.lbl_cinsiyet);
            this.groupBox1.Controls.Add(this.txt_ad);
            this.groupBox1.Controls.Add(this.lbl_telno);
            this.groupBox1.Controls.Add(this.chx_durum);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(24, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 347);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hasta Kayıt";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(274, 220);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(71, 21);
            this.checkBox2.TabIndex = 16;
            this.checkBox2.Text = "Kadın";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(161, 220);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(71, 21);
            this.checkBox1.TabIndex = 15;
            this.checkBox1.Text = "Erkek";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // btn_kaydet
            // 
            this.btn_kaydet.BackColor = System.Drawing.Color.DarkSalmon;
            this.btn_kaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kaydet.Location = new System.Drawing.Point(459, 273);
            this.btn_kaydet.Name = "btn_kaydet";
            this.btn_kaydet.Size = new System.Drawing.Size(118, 95);
            this.btn_kaydet.TabIndex = 0;
            this.btn_kaydet.Text = "KAYDET";
            this.btn_kaydet.UseVisualStyleBackColor = false;
            this.btn_kaydet.Click += new System.EventHandler(this.btn_kaydet_Click);
            // 
            // btn_düzenle
            // 
            this.btn_düzenle.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_düzenle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_düzenle.Location = new System.Drawing.Point(583, 323);
            this.btn_düzenle.Name = "btn_düzenle";
            this.btn_düzenle.Size = new System.Drawing.Size(118, 45);
            this.btn_düzenle.TabIndex = 1;
            this.btn_düzenle.Text = "DÜZENLE";
            this.btn_düzenle.UseVisualStyleBackColor = false;
            this.btn_düzenle.Click += new System.EventHandler(this.btn_düzenle_Click);
            // 
            // btn_sil
            // 
            this.btn_sil.Location = new System.Drawing.Point(103, 182);
            this.btn_sil.Name = "btn_sil";
            this.btn_sil.Size = new System.Drawing.Size(102, 37);
            this.btn_sil.TabIndex = 16;
            // 
            // btn_temizle
            // 
            this.btn_temizle.BackColor = System.Drawing.Color.LemonChiffon;
            this.btn_temizle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_temizle.Location = new System.Drawing.Point(583, 273);
            this.btn_temizle.Name = "btn_temizle";
            this.btn_temizle.Size = new System.Drawing.Size(118, 45);
            this.btn_temizle.TabIndex = 3;
            this.btn_temizle.Text = "TEMİZLE";
            this.btn_temizle.UseVisualStyleBackColor = false;
            this.btn_temizle.Click += new System.EventHandler(this.btn_temizle_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.lbl_soyadara);
            this.groupBox2.Controls.Add(this.btn_sil);
            this.groupBox2.Controls.Add(this.btn_hasta_ara);
            this.groupBox2.Controls.Add(this.txt_hastatc);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(454, 33);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(247, 229);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Hasta Arama";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(9, 132);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(196, 22);
            this.textBox1.TabIndex = 4;
            // 
            // lbl_soyadara
            // 
            this.lbl_soyadara.AutoSize = true;
            this.lbl_soyadara.Location = new System.Drawing.Point(9, 103);
            this.lbl_soyadara.Name = "lbl_soyadara";
            this.lbl_soyadara.Size = new System.Drawing.Size(56, 17);
            this.lbl_soyadara.TabIndex = 3;
            this.lbl_soyadara.Text = "Soyad :";
            // 
            // btn_hasta_ara
            // 
            this.btn_hasta_ara.Location = new System.Drawing.Point(6, 182);
            this.btn_hasta_ara.Name = "btn_hasta_ara";
            this.btn_hasta_ara.Size = new System.Drawing.Size(75, 37);
            this.btn_hasta_ara.TabIndex = 2;
            this.btn_hasta_ara.Text = "ARA";
            this.btn_hasta_ara.UseVisualStyleBackColor = true;
            this.btn_hasta_ara.Click += new System.EventHandler(this.btn_hasta_ara_Click);
            // 
            // txt_hastatc
            // 
            this.txt_hastatc.Location = new System.Drawing.Point(9, 58);
            this.txt_hastatc.Name = "txt_hastatc";
            this.txt_hastatc.Size = new System.Drawing.Size(196, 22);
            this.txt_hastatc.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "T.C No : ";
            // 
            // HastaKayit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(721, 390);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_temizle);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_düzenle);
            this.Controls.Add(this.btn_kaydet);
            this.Name = "HastaKayit";
            this.Text = "HastaKayit";
            this.Load += new System.EventHandler(this.HastaKayit_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_tcno;
        private System.Windows.Forms.Label lbl_ad;
        private System.Windows.Forms.Label lbl_soyad;
        private System.Windows.Forms.Label lbl_dt;
        private System.Windows.Forms.Label lbl_cinsiyet;
        private System.Windows.Forms.Label lbl_telno;
        private System.Windows.Forms.CheckBox chx_durum;
        private System.Windows.Forms.TextBox txt_tc;
        private System.Windows.Forms.TextBox txt_ad;
        private System.Windows.Forms.TextBox txt_soyad;
        private System.Windows.Forms.TextBox txt_telno;
        private System.Windows.Forms.DateTimePicker dtp_dt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_kaydet;
        private System.Windows.Forms.Button btn_düzenle;
        private System.Windows.Forms.Button btn_sil;
        private System.Windows.Forms.Button btn_temizle;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_hastatc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_hasta_ara;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbl_soyadara;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}